# api/serializers.py

from rest_framework import serializers # type: ignore

from .models import Song
 

class SongSerializer(serializers.ModelSerializer):

    class Meta:

        model = Song

        fields = '__all__'